import sublime_plugin

class MoveTabCommand(sublime_plugin.WindowCommand):
    def run(self, mod):
        view = self.window.active_view()
        group_index, tab_index = self.window.get_view_index(view)
        self.window.set_view_index(view, group_index,
            (tab_index + int(mod)) % len (
                self.window.views_in_group(group_index)) )
        self.window.focus_view(view)
